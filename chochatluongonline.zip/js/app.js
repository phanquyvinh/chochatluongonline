/**
 * chochatluongonline — UI helpers & marketplace logic
 */
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

function formatVND(n) {
  return Number(n || 0).toLocaleString('vi-VN') + ' đ';
}
function formatPct(rate) {
  return (Number(rate || 0) * 100).toFixed(2).replace(/\.?0+$/, '') + '%';
}
function stars(n) {
  const r = Math.round(Number(n) || 0);
  return '★'.repeat(r) + '☆'.repeat(5 - r);
}

function toast(message, type = 'info') {
  let box = $('.toast-container');
  if (!box) {
    box = document.createElement('div');
    box.className = 'toast-container';
    document.body.appendChild(box);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 3200);
}

function getSession() {
  return window.CCLStore ? CCLStore.getSession() : null;
}

function requireAuth(roles) {
  const s = getSession();
  if (!s) {
    toast('Vui lòng đăng nhập', 'error');
    setTimeout(() => (location.href = '/login.html'), 600);
    return null;
  }
  if (roles && !roles.includes(s.role)) {
    toast('Không có quyền truy cập', 'error');
    setTimeout(() => (location.href = '/'), 600);
    return null;
  }
  if (CCLStore.isBlocked(s.email)) {
    toast('Tài khoản đã bị khóa', 'error');
    CCLStore.clearSession();
    setTimeout(() => (location.href = '/login.html'), 800);
    return null;
  }
  return s;
}

function logout() {
  if (window.CCLStore) CCLStore.clearSession();
  toast('Đã đăng xuất', 'info');
  setTimeout(() => (location.href = '/'), 400);
}

function getCart() {
  try { return JSON.parse(localStorage.getItem('ccl_cart_v2') || '[]'); }
  catch { return []; }
}
function saveCart(cart) {
  localStorage.setItem('ccl_cart_v2', JSON.stringify(cart));
  updateCartBadge();
}
function updateCartBadge() {
  const cart = getCart();
  const q = cart.reduce((s, i) => s + (i.qty || 1), 0);
  $$('[data-cart-count]').forEach((el) => {
    el.textContent = q;
    el.style.display = q > 0 ? 'flex' : 'none';
  });
}

function addToCart(itemId) {
  const item = CCLStore.getProductById(itemId);
  if (!item) return;
  const shop = CCLConfig.loadShopSettings(item.shopId);
  if (shop.acceptOrders === false) {
    toast('Gian hàng tạm ngưng nhận đơn', 'error');
    return;
  }
  const cart = getCart();
  const ex = cart.find((c) => c.id === itemId);
  if (ex) { ex.qty = (ex.qty || 1) + 1; ex.price = item.price; }
  else cart.push({ ...item, qty: 1 });
  saveCart(cart);
  toast('Đã thêm vào giỏ', 'success');
  if (typeof renderCart === 'function') renderCart();
}

function changeQty(id, d) {
  let cart = getCart();
  const row = cart.find((c) => c.id === id);
  if (!row) return;
  row.qty = Math.max(0, (row.qty || 1) + d);
  cart = cart.filter((c) => c.qty > 0);
  saveCart(cart);
  if (typeof renderCart === 'function') renderCart();
}

function removeFromCart(id) {
  saveCart(getCart().filter((c) => c.id !== id));
  if (typeof renderCart === 'function') renderCart();
}

function renderUserNav() {
  const el = $('#userNav');
  if (!el) return;
  const s = getSession();
  if (s) {
    const initial = (s.name || s.email || 'U').charAt(0).toUpperCase();
    el.innerHTML = `
      <div class="nav-user">
        <div class="avatar">${initial}</div>
        <span style="font-size:0.9rem;font-weight:600">${s.name || s.email}</span>
        ${s.role === 'admin' ? '<a href="/admin.html" class="btn btn-ghost btn-sm">Quản trị</a>' : ''}
        ${s.role === 'seller' ? '<a href="/seller.html" class="btn btn-ghost btn-sm">Gian hàng</a>' : ''}
        ${s.role === 'buyer' || s.role === 'admin' ? '<a href="/orders.html" class="btn btn-ghost btn-sm">Đơn hàng</a>' : ''}
        <button class="btn btn-outline btn-sm" onclick="logout()">Thoát</button>
      </div>`;
  } else {
    el.innerHTML = `
      <a href="/login.html" class="btn btn-ghost btn-sm">Đăng nhập</a>
      <a href="/register.html" class="btn btn-primary btn-sm">Đăng ký</a>`;
  }
}

function productCard(item) {
  const shop = CCLConfig.loadShopSettings(item.shopId);
  const img = (item.images && item.images[0])
    ? `<img src="${item.images[0]}" alt="" style="width:100%;height:100%;object-fit:cover">`
    : `<span style="font-size:2.4rem">${item.emoji || '📦'}</span>`;
  const rc = item.reviewsCount || 0;
  return `
  <article class="card">
    <a href="/product.html?id=${item.id}" class="card-img">${img}
      <span class="card-badge ${item.type === 'product' ? 'badge-product' : 'badge-service'}">${item.type === 'product' ? 'Sản phẩm' : 'Dịch vụ'}</span>
    </a>
    <div class="card-body">
      <a href="/shop.html?id=${item.shopId}" class="card-shop">🏪 ${item.shopName}</a>
      <a href="/product.html?id=${item.id}" class="card-title">${item.name}</a>
      <div class="card-meta"><span>${stars(item.rating)} ${item.rating || 0}</span><span>·</span><span>${rc} đánh giá</span></div>
      <div class="card-price">
        <div class="price">${formatVND(item.price)}</div>
        <button class="btn btn-primary btn-sm" onclick="event.preventDefault();addToCart('${item.id}')">Thêm</button>
      </div>
    </div>
  </article>`;
}

let currentFilter = 'all';
function setFilter(f) {
  currentFilter = f;
  $$('.chip').forEach((c) => c.classList.toggle('active', c.dataset.filter === f));
  renderCatalog();
}
function renderCatalog() {
  const pg = $('#productsGrid'), sg = $('#servicesGrid');
  if (!pg || !sg) return;
  const q = ($('#searchInput')?.value || '').trim().toLowerCase();
  let items = CCLStore.getProducts();
  items = items.filter((item) => {
    if (currentFilter === 'product' && item.type !== 'product') return false;
    if (currentFilter === 'service' && item.type !== 'service') return false;
    if (!['all', 'product', 'service'].includes(currentFilter) && item.category !== currentFilter) return false;
    if (q && !`${item.name} ${item.shopName}`.toLowerCase().includes(q)) return false;
    return true;
  });
  const products = items.filter((i) => i.type === 'product');
  const services = items.filter((i) => i.type === 'service');
  pg.innerHTML = products.length ? products.map(productCard).join('') : '<p class="empty-msg">Không có sản phẩm</p>';
  sg.innerHTML = services.length ? services.map(productCard).join('') : '<p class="empty-msg">Không có dịch vụ</p>';
}

function renderCart() {
  const container = $('#cartContainer');
  const summary = $('#cartSummary');
  if (!container) return;
  const cart = getCart();
  if (!cart.length) {
    container.innerHTML = `<div class="cart-empty"><div class="empty-icon">🛒</div><p>Giỏ hàng trống</p></div>`;
    if (summary) summary.style.display = 'none';
    updateCartBadge();
    return;
  }
  cart.forEach((c) => {
    const live = CCLStore.getProductById(c.id);
    if (live) c.price = live.price;
  });
  saveCart(cart);
  const voucherCode = $('#voucherInput')?.value || '';
  const totals = CCLConfig.calcOrderTotals(cart, { code: voucherCode });
  const groups = {};
  cart.forEach((item) => {
    if (!groups[item.shopId]) groups[item.shopId] = [];
    groups[item.shopId].push(item);
  });
  let html = '';
  totals.shopBreakdown.forEach((bd) => {
    const items = groups[bd.shopId] || [];
    html += `<div class="shop-group"><div class="shop-header"><span>🏪 ${bd.shopName}</span><span class="ship-badge">${bd.freeShip ? 'Miễn ship' : 'Ship ' + formatVND(bd.ship)}</span></div>`;
    items.forEach((item) => {
      html += `<div class="cart-item">
        <div class="cart-item-info"><div class="cart-item-name">${item.name}</div>
        <div class="cart-item-type">${formatVND(item.price)} × ${item.qty || 1}</div></div>
        <div class="qty-control">
          <button class="qty-btn" onclick="changeQty('${item.id}',-1)">−</button>
          <span class="qty-val">${item.qty || 1}</span>
          <button class="qty-btn" onclick="changeQty('${item.id}',1)">+</button>
        </div>
        <div class="cart-item-price">${formatVND(item.price * (item.qty || 1))}</div>
        <button class="btn btn-ghost btn-sm" onclick="removeFromCart('${item.id}')">✕</button>
      </div>`;
    });
    html += '</div>';
  });
  container.innerHTML = html;
  if (summary) {
    summary.style.display = 'block';
    $('#sumItems').textContent = formatVND(totals.totalItems);
    $('#sumShip').textContent = formatVND(totals.totalShip);
    $('#sumFeeNote').textContent = `Phí sàn ${formatPct(totals.feeRate)} (trừ khi giải ngân): ${formatVND(totals.platformFee)}`;
    const discRow = $('#sumDiscountRow');
    if (discRow) {
      if (totals.discount > 0) {
        discRow.style.display = 'flex';
        $('#sumDiscount').textContent = '−' + formatVND(totals.discount);
      } else discRow.style.display = 'none';
    }
    $('#sumTotal').textContent = formatVND(totals.grandTotal);
    const btn = $('#checkoutBtn');
    if (btn) btn.disabled = !totals.canCheckout;
  }
  updateCartBadge();
}

function applyVoucher() { renderCart(); }

async function checkoutOrder() {
  const s = getSession();
  if (!s) {
    toast('Vui lòng đăng nhập', 'error');
    setTimeout(() => (location.href = '/login.html'), 600);
    return;
  }
  if (s.role === 'seller') {
    toast('Tài khoản bán hàng không đặt đơn mua', 'error');
    return;
  }
  if (CCLStore.isBlocked(s.email)) {
    toast('Tài khoản bị khóa', 'error');
    return;
  }
  const cart = getCart();
  if (!cart.length) return;
  const totals = CCLConfig.calcOrderTotals(cart, { code: $('#voucherInput')?.value || '' });
  if (!totals.canCheckout) {
    toast('Không thể đặt hàng', 'error');
    return;
  }
  const bank = $('#bankSelect')?.value || 'Vietcombank';
  const order = {
    id: 'ORD-' + Date.now().toString(36).toUpperCase(),
    buyerEmail: s.email,
    buyerName: s.name,
    cart, totals, bank,
    status: 'held',
    createdAt: new Date().toISOString(),
  };
  CCLStore.saveOrder(order);
  saveCart([]);
  renderCart();
  toast('Đặt hàng thành công — tiền đang tạm giữ', 'success');
}

function initHome() {
  CCLStore.ensureProducts();
  renderUserNav();
  renderCatalog();
  renderCart();
  updateCartBadge();
  const search = $('#searchInput');
  if (search) search.addEventListener('input', () => renderCatalog());
}

window.formatVND = formatVND;
window.formatPct = formatPct;
window.stars = stars;
window.toast = toast;
window.logout = logout;
window.addToCart = addToCart;
window.changeQty = changeQty;
window.removeFromCart = removeFromCart;
window.setFilter = setFilter;
window.renderCart = renderCart;
window.applyVoucher = applyVoucher;
window.checkoutOrder = checkoutOrder;
window.initHome = initHome;
window.getSession = getSession;
window.requireAuth = requireAuth;
window.renderUserNav = renderUserNav;
